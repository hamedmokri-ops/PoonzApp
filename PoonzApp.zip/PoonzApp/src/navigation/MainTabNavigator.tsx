import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { View, TouchableOpacity, StyleSheet } from "react-native";
import HomeScreen from "../screens/home/HomeScreen";
import OrdersScreen from "../screens/order/OrdersScreen";
import WalletScreen from "../screens/wallet/WalletScreen";
import SettingsScreen from "../screens/profile/SettingsScreen";
import { Ionicons } from "@expo/vector-icons";

const Tab = createBottomTabNavigator();

export default function MainTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: "#ffffff",
          height: 65,
          borderTopWidth: 0,
          elevation: 10,
        },
      }}
    >
      {/* Home */}
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Ionicons name="home-outline" size={26} color={color} />
          ),
        }}
      />

      {/* Orders */}
      <Tab.Screen
        name="Orders"
        component={OrdersScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Ionicons name="file-tray-full-outline" size={26} color={color} />
          ),
        }}
      />

      {/* مرکز: دکمه پاپ‌آپ فیلتر */}
      <Tab.Screen
        name="FilterButton"
        component={() => null}
        options={{
          tabBarButton: () => (
            <TouchableOpacity style={styles.centerButton}>
              <Ionicons name="options-outline" size={32} color="#ffffff" />
            </TouchableOpacity>
          ),
        }}
      />

      {/* Wallet */}
      <Tab.Screen
        name="Wallet"
        component={WalletScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Ionicons name="wallet-outline" size={26} color={color} />
          ),
        }}
      />

      {/* Settings */}
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Ionicons name="settings-outline" size={26} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  centerButton: {
    width: 65,
    height: 65,
    borderRadius: 40,
    backgroundColor: "#007AFF",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
    elevation: 5,
  },
});